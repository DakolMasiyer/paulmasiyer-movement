
function generatePoster(){
const canvas=document.getElementById('canvas');
const ctx=canvas.getContext('2d');
ctx.fillStyle="#0b3d2e";
ctx.fillRect(0,0,600,800);

ctx.fillStyle="#fff";
ctx.font="bold 28px Arial";
ctx.fillText("I SUPPORT PMM",120,200);

let name=document.getElementById('name').value;
ctx.fillText(name,120,300);
}
